CSSBox
======
An HTML/CSS rendering engine library
(c) 2005-2015 Radek Burget (burgetr@fit.vutbr.cz)

See the project page for more information and downloads:
[http://cssbox.sourceforge.net/](http://cssbox.sourceforge.net/)

All the source code of the CSSBox itself is licensed under the GNU Lesser General
Public License (LGPL), version 3. A copy of the LGPL can be found 
in the LICENSE file.

CSSBox relies on the jStyleParser open source CSS parser 
[http://cssbox.sourceforge.net/jstyleparser](http://cssbox.sourceforge.net/jstyleparser).

The CSSBox library is under development and its API or functionality may change in future versions.
See the CHANGELOG for the most important changes to the previous versions.
