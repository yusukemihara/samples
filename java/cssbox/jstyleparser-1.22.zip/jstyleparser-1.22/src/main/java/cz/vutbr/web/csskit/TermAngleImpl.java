package cz.vutbr.web.csskit;

import cz.vutbr.web.css.TermAngle;

public class TermAngleImpl extends TermFloatValueImpl implements TermAngle {

	protected TermAngleImpl() {
		
	}
	
}
