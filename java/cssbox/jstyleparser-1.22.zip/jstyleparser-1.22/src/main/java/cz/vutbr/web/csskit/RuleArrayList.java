/**
 * RuleArrayList.java
 *
 * Created on 30. 6. 2014, 14:26:17 by burgetr
 */
package cz.vutbr.web.csskit;

import java.util.ArrayList;

import cz.vutbr.web.css.RuleBlock;
import cz.vutbr.web.css.RuleList;

/**
 * 
 * @author burgetr
 */
public class RuleArrayList extends ArrayList<RuleBlock<?>> implements RuleList
{
    private static final long serialVersionUID = 1L;

}
