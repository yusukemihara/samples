/**
 * RuleFontFace.java
 *
 * Created on 1.2.2013, 14:27:04 by burgetr
 */
package cz.vutbr.web.css;

/**
 * Contains collection of CSS declarations specified for a given font.
 * 
 * @author burgetr
 */
public interface RuleFontFace extends RuleBlock<Declaration>, PrettyOutput
{

}
