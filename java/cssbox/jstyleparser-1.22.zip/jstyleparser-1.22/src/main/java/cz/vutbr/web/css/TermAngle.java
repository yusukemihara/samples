package cz.vutbr.web.css;

public interface TermAngle extends TermFloatValue {

}
