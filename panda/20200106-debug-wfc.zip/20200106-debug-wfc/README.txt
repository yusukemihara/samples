# wfc終了時のgdbバックトレース取得

## 概要

wfcが異常終了する原因を調べるため、異常終了時のバックトレースを取得できるようにする。

## 前提条件

* 日レセ5.0
    * (5.1でもおそらく同様の設定が可能)
* Ubuntu 16.04

## 適用手順

gdbのインストール
$ sudo apt install gdb

gdbwfc.shの設置
$ sudo cp gdbwfc.sh /usr/local/sbin

/etc/init.d/jma-receiptの置き換え
$ sudo cp jma-receipt /etc/init.d/
(差分 init.d.jma-receipt.diff)

/etc/init.d/jma-receiptのreload
$ sudo systemctl daemon-reload

日レセ再起動
$ sudo systemctl restart jma-receipt

## 動作概要

日レセ起動時(wfc初回起動時)にwfcのプロセスにgdbをアタッチする。
(/etc/init.d/jma-receiptにてmonitor起動後(wfc起動後)に/usr/local/sbin/gdbwfc.shを実行してwfcのPIDにgdbを接続する。)
ログは/tmp/${date -Iseconds}.wfc.log.txtに作成される。
wfcプロセス終了時にログにバックトレースを出力する。
異常終了時のログ(バックトレース)を確認することでエラー箇所が特定できる可能性がある。

## 注意点

gdbログ取得は/etc/init.d/jma-receiptでの初回起動時のみ行われる。
monitorによるwfc再起動の場合はgdb起動しない。
